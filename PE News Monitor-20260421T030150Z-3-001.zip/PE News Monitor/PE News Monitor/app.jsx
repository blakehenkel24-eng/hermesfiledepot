// PE News Monitor — simplified: AI Brief + RSS news + Firm profiles repo
const { useState, useEffect, useMemo } = React;

const Icon = ({ d, size = 14, stroke = 1.5 }) => (
  <svg className="icon" width={size} height={size} viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth={stroke} strokeLinecap="round" strokeLinejoin="round">
    <path d={d} />
  </svg>
);
const IconSearch = () => <Icon d="M7 12.5a5.5 5.5 0 1 0 0-11 5.5 5.5 0 0 0 0 11Zm4-1.5 3.5 3.5" />;
const IconBell = () => <Icon d="M8 1.5v1M4 6a4 4 0 1 1 8 0v3l1.5 2.5h-11L4 9V6Zm2 6.5a2 2 0 0 0 4 0" />;
const IconSettings = () => <Icon d="M8 10.5a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5Zm0-9v2M8 12.5v2m6.5-6.5h-2M3.5 8h-2m10.6-4.6-1.4 1.4M4.3 11.7l-1.4 1.4m9.2 0-1.4-1.4M4.3 4.3 2.9 2.9" />;
const IconPlus = () => <Icon d="M8 3v10M3 8h10" />;
const IconX = () => <Icon d="M3 3l10 10M13 3L3 13" />;
const IconChev = () => <Icon d="M6 3l5 5-5 5" />;
const IconCheck = () => <Icon d="M3 8l3.5 3.5L13 4" stroke={2} />;
const IconNews = () => <Icon d="M2.5 3h9v10h-9V3Zm9 2.5H14v7.5H2.5M5 5.5h4M5 7.5h4M5 9.5h4" />;
const IconStar = () => <Icon d="M8 2l1.8 3.7 4.2.6-3 3 .7 4.1L8 11.5l-3.7 1.9.7-4.1-3-3 4.2-.6L8 2Z" />;
const IconBook = () => <Icon d="M3 2h4a2 2 0 0 1 2 2v10a1.5 1.5 0 0 0-1.5-1.5H3V2Zm10 0H9a2 2 0 0 0-2 2v10a1.5 1.5 0 0 1 1.5-1.5H13V2Z" />;

const today = () => new Date(2026, 3, 20).toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric', year: 'numeric' });
const todayShort = () => new Date(2026, 3, 20).toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' }).toUpperCase();
const impactWord = { high: "HIGH", med: "MED", low: "LOW" };

function Topbar() {
  const p = window.PE_MARKET_PULSE;
  return (
    <div className="topbar">
      <div className="topbar-left">
        <div className="date-chip"><span className="dot"></span>LIVE · {todayShort()} · 07:42 ET</div>
        <div className="market-pill">
          DEALS 24H <b>{p.dealCount24h}</b> <span className="delta-pos">{p.dealCount24hDelta}</span>
          <span className="sep">│</span>
          FUND CLOSES <b>{p.fundCloseCount}</b> <span className="delta-pos">{p.fundCloseCountDelta}</span>
          <span className="sep">│</span>
          SR. MOVES <b>{p.seniorHires}</b> <span className="delta-neg">{p.seniorHiresDelta}</span>
        </div>
      </div>
      <div className="topbar-right">
        <div className="search-box">
          <IconSearch />
          <input placeholder="Search firms, deals, people…" />
          <span className="kbd">⌘K</span>
        </div>
        <button className="topbar-icon-btn" title="Alerts"><IconBell /><span className="badge"></span></button>
        <button className="topbar-icon-btn" title="Settings"><IconSettings /></button>
        <div className="user-chip">
          <div className="avatar">MR</div>
          <div className="user-name">m.reyes</div>
        </div>
      </div>
    </div>
  );
}

function Sidebar({ view, setView, activeFirm, setActiveFirm, firms, onOpenWatchlist }) {
  const watched = firms.filter(f => f.watched);
  return (
    <aside className="sidebar">
      <div className="sidebar-section">
        <div className="sidebar-section-header"><div className="label">Views</div></div>
        <div className={`nav-item ${view === "briefing" && !activeFirm ? "active" : ""}`} onClick={() => { setView("briefing"); setActiveFirm(null); }}>
          <span className="nav-icon"><IconNews /></span>
          Daily briefing
          <span className="nav-count">{window.PE_STORIES.length}</span>
        </div>
        <div className={`nav-item ${view === "repo" ? "active" : ""}`} onClick={() => { setView("repo"); setActiveFirm(null); }}>
          <span className="nav-icon"><IconBook /></span>
          Firm profiles
          <span className="nav-count">{firms.length}</span>
        </div>
        <div className={`nav-item ${view === "saved" ? "active" : ""}`} onClick={() => { setView("saved"); setActiveFirm(null); }}>
          <span className="nav-icon"><IconStar /></span>
          Saved
          <span className="nav-count">4</span>
        </div>
      </div>

      <div className="sidebar-section">
        <div className="sidebar-section-header">
          <div className="label">Watchlist</div>
          <div className="count">{watched.length}</div>
        </div>
        {watched.map(f => (
          <div
            key={f.id}
            className={`firm-item ${activeFirm === f.id ? "active" : ""}`}
            onClick={() => { setActiveFirm(f.id); setView("firm"); }}
          >
            <span className={`rel-dot ${f.relationship}`}></span>
            <div className="firm-short">{f.short}</div>
            <div className={`firm-unread ${f.unread === 0 ? "zero" : ""}`}>{f.unread}</div>
          </div>
        ))}
        <button className="add-firm-btn" onClick={onOpenWatchlist}>
          <IconPlus /> Manage watchlist
        </button>
      </div>
    </aside>
  );
}

function AISummary({ firms }) {
  const watched = firms.filter(f => f.watched);
  const totalUnread = watched.reduce((s, f) => s + f.unread, 0);
  return (
    <div className="ai-summary">
      <div className="ai-summary-badge">
        <div className="ai-dot"></div>
        <div>
          <div className="label">Market Brief</div>
          <div className="mono" style={{ fontSize: 10, color: 'var(--muted)', marginTop: 3, letterSpacing: '0.08em' }}>GEN 07:15 ET</div>
        </div>
      </div>
      <div className="ai-summary-body">
        <p style={{margin: 0}}><b>Overnight: {totalUnread} developments across {watched.length} firms on watch — 4 high-impact, 3 medium.</b> <span className="firm-ref">PLATINUM</span> closed the $2.1B HarborLine take-private at 11.4x EBITDA, opened a Jefferies-led sale process for Simcom Aviation ($1.2–1.4B), and hired Anjali Rao from Carlyle as Head of Portfolio Ops. <span className="firm-ref">GEMSPRING</span> closed Fund IV at a $2.4B hard cap — 33% over target, with 95%+ LP re-ups — and has already deployed into Beaumont Machining, a carve-out from a publicly traded diversified manufacturer. <span className="firm-ref">NAUTIC</span> filed Form D for Fund XI at $1.5B and added Meridian Specialty Coatings to its Kelvin platform, the fourth tuck-in in 18 months. <span className="firm-ref">CDNR</span>'s Vantage Analytics acquired ClearSignal for $180M, roughly doubling ARR; the firm also promoted three to partner and is opening an Austin office. <span className="firm-ref">APCO</span> is working with Evercore on a two-asset continuation vehicle, and portfolio company ProShield signed a 240-rooftop dealer partnership. <b>Net read:</b> Q2 deployment is accelerating on fresh capital, carve-outs and founder tuck-ins dominate middle-market supply, and senior PortOps hires this week at Platinum echo similar moves at Carlyle and KKR last month — value-creation muscle is the GP battleground heading into the back half of '26.</p>
      </div>
      <div className="ai-summary-actions">
        <button onClick={() => {
          const txt = document.querySelector('.ai-summary-body')?.innerText || '';
          navigator.clipboard?.writeText(txt);
        }}>COPY</button>
        <button>REGENERATE</button>
      </div>
    </div>
  );
}

function FilterBar({ filter, setFilter, counts, viewMode, setViewMode }) {
  const types = ["All", "Deal", "Fund", "Leadership", "Portfolio"];
  return (
    <div className="filter-bar">
      <div className="filter-bar-left">
        {types.map(t => (
          <button key={t} className={`filter-chip ${filter === t ? "active" : ""}`} onClick={() => setFilter(t)}>
            {t.toUpperCase()} <span className="count">{counts[t] || 0}</span>
          </button>
        ))}
      </div>
      <div className="filter-bar-right">
        <div className="view-toggle">
          <button className={viewMode === "comfortable" ? "active" : ""} onClick={() => setViewMode("comfortable")}>COMFORT</button>
          <button className={viewMode === "compact" ? "active" : ""} onClick={() => setViewMode("compact")}>COMPACT</button>
        </div>
      </div>
    </div>
  );
}

function StoryRow({ story, firm, expanded, onToggle, viewMode }) {
  const timeMap = { "2h": "05:42", "4h": "03:51", "5h": "02:38", "6h": "01:45", "8h": "23:20", "10h": "21:18", "12h": "19:04", "14h": "17:20", "1d": "YDAY" };
  return (
    <>
      <div className={`story-row ${expanded ? "expanded" : ""}`} onClick={onToggle}>
        <div className="story-time">
          <div className="time-main">{timeMap[story.timeAgo] || story.timeAgo}</div>
          <div className="time-ago">{story.timeAgo} AGO</div>
        </div>
        <div>
          <div className="story-firm">{firm.short}</div>
          <div className="story-firm-line">
            <span className={`rel-dot ${firm.relationship}`}></span>{firm.relationship.toUpperCase()}
          </div>
        </div>
        <div className="story-content">
          <div className="story-type-row">
            <span className={`type-tag ${story.type}`}>{story.type}</span>
            <span className={`impact-mark ${story.impact}`}>
              <span className="bar"></span>{impactWord[story.impact]} IMPACT
            </span>
          </div>
          <h3 className="story-headline">{story.headline}</h3>
          {viewMode !== "compact" && <p className="story-dek">{story.dek}</p>}
          {viewMode !== "compact" && (
            <div className="story-tags">
              {story.tags.map(t => <span key={t} className="tag">{t}</span>)}
            </div>
          )}
        </div>
        <div className="story-metric">
          <div className="story-metric-value">{story.metric.value}</div>
          <div className="story-metric-label">{story.metric.label}</div>
        </div>
        <div className="story-source">
          <span className={`tier ${story.sourceTier === 2 ? "t2" : story.sourceTier === 3 ? "t3" : ""}`}></span>
          {story.source}
        </div>
        <div className="story-chev"><IconChev /></div>
      </div>
      {expanded && (
        <div className="story-row expanded" style={{ paddingTop: 0, borderTop: 'none', cursor: 'default' }} onClick={e => e.stopPropagation()}>
          <div></div>
          <div></div>
          <div className="story-expanded-body">
            {story.body.split("\n\n").map((p, i) => <p key={i}>{p}</p>)}
            <div className="story-expanded-actions">
              <button>★ SAVE</button>
              <button>SHARE</button>
              <button>OPEN SOURCE</button>
              <button>ADD TO MEMO</button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}

function BriefingView({ firms, viewMode, setViewMode, expandedStory, setExpandedStory }) {
  const [filter, setFilter] = useState("All");
  const watched = firms.filter(f => f.watched);
  const watchedIds = new Set(watched.map(f => f.id));
  const stories = window.PE_STORIES.filter(s => watchedIds.has(s.firmId));

  const counts = useMemo(() => {
    const c = { All: stories.length };
    stories.forEach(s => { c[s.type] = (c[s.type] || 0) + 1; });
    return c;
  }, [stories]);

  const filtered = filter === "All" ? stories : stories.filter(s => s.type === filter);

  return (
    <>
      <div className="briefing-header">
        <div className="kicker">Morning briefing · {today()}</div>
        <h1 className="briefing-title">Good morning. Here is your <span className="accent">daily PE briefing.</span></h1>
        <div className="briefing-meta">
          <span>Clients <b>{watched.length}</b></span>
          <span>Stories <b>{stories.length}</b></span>
          <span>High-impact <b>{stories.filter(s => s.impact === "high").length}</b></span>
          <span>Sources <b>14</b></span>
        </div>
      </div>

      <div className="briefing-stats">
        <div className="stat"><div className="stat-label">Deals 24h</div><div className="stat-value">47</div><div className="stat-delta pos">+12 vs 7d avg</div></div>
        <div className="stat"><div className="stat-label">Fund closes</div><div className="stat-value">3</div><div className="stat-delta pos">+1 vs 7d</div></div>
        <div className="stat"><div className="stat-label">Senior moves</div><div className="stat-value">8</div><div className="stat-delta neg">-2 vs 7d</div></div>
        <div className="stat"><div className="stat-label">Agg. deal value</div><div className="stat-value">$14.8B</div><div className="stat-delta pos">+$3.2B</div></div>
      </div>

      <AISummary firms={firms} />

      <FilterBar filter={filter} setFilter={setFilter} counts={counts} viewMode={viewMode} setViewMode={setViewMode} />

      <div className="story-list">
        {filtered.map(s => {
          const firm = firms.find(f => f.id === s.firmId);
          return (
            <StoryRow
              key={s.id}
              story={s}
              firm={firm}
              expanded={expandedStory === s.id}
              onToggle={() => setExpandedStory(expandedStory === s.id ? null : s.id)}
              viewMode={viewMode}
            />
          );
        })}
      </div>
    </>
  );
}

// ---------- Firm Profiles Repo ----------
function FirmRepo({ firms, setActiveFirm, setView }) {
  const [q, setQ] = useState("");
  const [sortBy, setSortBy] = useState("name");
  const [filter, setFilter] = useState("All");

  const filters = ["All", "Watched", "Mid-market", "Large-cap", "By sector"];

  let filtered = firms.filter(f =>
    f.name.toLowerCase().includes(q.toLowerCase()) ||
    f.short.toLowerCase().includes(q.toLowerCase()) ||
    f.strategy.toLowerCase().includes(q.toLowerCase()) ||
    f.sectors.join(" ").toLowerCase().includes(q.toLowerCase())
  );
  if (filter === "Watched") filtered = filtered.filter(f => f.watched);
  if (filter === "Mid-market") filtered = filtered.filter(f => parseFloat(f.aum) < 15);
  if (filter === "Large-cap") filtered = filtered.filter(f => parseFloat(f.aum) >= 15);

  const sorted = [...filtered].sort((a, b) => {
    if (sortBy === "aum") return parseFloat(b.aum) - parseFloat(a.aum);
    if (sortBy === "founded") return a.founded - b.founded;
    return a.name.localeCompare(b.name);
  });

  return (
    <div className="repo">
      <div className="briefing-header">
        <div className="kicker">Database · {firms.length} firms on file</div>
        <h1 className="briefing-title">Private equity <span className="accent">firm profiles.</span></h1>
        <div className="briefing-meta">
          <span>Total AUM tracked <b>${firms.reduce((s, f) => s + parseFloat(f.aum), 0).toFixed(1)}B</b></span>
          <span>Watched <b>{firms.filter(f => f.watched).length}</b></span>
          <span>Mid-market <b>{firms.filter(f => parseFloat(f.aum) < 15).length}</b></span>
          <span>Large-cap <b>{firms.filter(f => parseFloat(f.aum) >= 15).length}</b></span>
        </div>
      </div>

      <div className="filter-bar">
        <div className="filter-bar-left">
          <div className="repo-search">
            <IconSearch />
            <input placeholder="Search by firm, strategy, sector…" value={q} onChange={e => setQ(e.target.value)} />
          </div>
          {filters.map(f => (
            <button key={f} className={`filter-chip ${filter === f ? "active" : ""}`} onClick={() => setFilter(f)}>
              {f.toUpperCase()}
            </button>
          ))}
        </div>
        <div className="filter-bar-right">
          <span style={{fontFamily: 'var(--font-sans)', fontSize: 10, letterSpacing: '0.1em', color: 'var(--muted)', fontWeight: 600, textTransform: 'uppercase', marginRight: 8}}>Sort</span>
          <div className="view-toggle">
            <button className={sortBy === "name" ? "active" : ""} onClick={() => setSortBy("name")}>A–Z</button>
            <button className={sortBy === "aum" ? "active" : ""} onClick={() => setSortBy("aum")}>AUM</button>
            <button className={sortBy === "founded" ? "active" : ""} onClick={() => setSortBy("founded")}>VINTAGE</button>
          </div>
        </div>
      </div>

      <div className="repo-grid">
        {sorted.map(f => (
          <div key={f.id} className="firm-card" onClick={() => { setActiveFirm(f.id); setView("firm"); }}>
            <div className="firm-card-top">
              <div className="firm-card-short">{f.short}</div>
              {f.watched && <span className="watched-badge">★ WATCH</span>}
            </div>
            <h3 className="firm-card-name">{f.name}</h3>
            <div className="firm-card-strategy">{f.strategy}</div>
            <div className="firm-card-sectors">
              {f.sectors.slice(0, 3).map(s => <span key={s} className="sector-chip">{s}</span>)}
            </div>
            <div className="firm-card-stats">
              <div><div className="v">${f.aum}</div><div className="l">AUM</div></div>
              <div><div className="v">{f.founded}</div><div className="l">Founded</div></div>
              <div><div className="v">{f.hq.split(",")[0]}</div><div className="l">HQ</div></div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ---------- Firm Detail ----------
function FirmDetail({ firmId, firms, setFirms, setActiveFirm, setView, expandedStory, setExpandedStory, viewMode, setViewMode }) {
  const firm = firms.find(f => f.id === firmId);
  const toggleWatch = () => setFirms(firms.map(f => f.id === firmId ? { ...f, watched: !f.watched } : f));
  const stories = window.PE_STORIES.filter(s => s.firmId === firmId);
  const [filter, setFilter] = useState("All");
  const counts = useMemo(() => {
    const c = { All: stories.length };
    stories.forEach(s => { c[s.type] = (c[s.type] || 0) + 1; });
    return c;
  }, [stories]);
  const filtered = filter === "All" ? stories : stories.filter(s => s.type === filter);

  return (
    <div className="firm-detail">
      <div className="firm-detail-header">
        <div>
          <div className="firm-crumb">
            <a onClick={() => { setView("briefing"); setActiveFirm(null); }}>DAILY BRIEFING</a>
            <span className="sep">/</span>
            <a onClick={() => { setView("repo"); setActiveFirm(null); }}>PROFILES</a>
            <span className="sep">/</span>
            <span style={{ color: 'var(--accent)' }}>{firm.short}</span>
          </div>
          <h1 className="firm-detail-name">{firm.name}</h1>
          <div className="firm-short-label">{firm.short} · {firm.strategy}</div>
          <div className="firm-actions">
            <button className={`watch-btn ${firm.watched ? "on" : ""}`} onClick={toggleWatch}>
              <span className="watch-star">{firm.watched ? "★" : "☆"}</span>
              {firm.watched ? "On watchlist" : "Add to watchlist"}
            </button>
            <button className="firm-action-btn">Share</button>
            <button className="firm-action-btn">Export profile</button>
          </div>
        </div>
        <div className="firm-facts">
          <div className="firm-fact"><div className="firm-fact-value">${firm.aum}</div><div className="firm-fact-label">AUM</div></div>
          <div className="firm-fact"><div className="firm-fact-value">{firm.founded}</div><div className="firm-fact-label">Founded</div></div>
          <div className="firm-fact"><div className="firm-fact-value">{stories.length}</div><div className="firm-fact-label">Stories 30d</div></div>
          <div className="firm-fact"><div className="firm-fact-value">{firm.unread}</div><div className="firm-fact-label">Unread</div></div>
        </div>
      </div>

      <div className="profile-panel">
        <div className="profile-col">
          <h4>Firm at a glance</h4>
          <div className="profile-line"><span className="k">HQ</span><span className="v">{firm.hq}</span></div>
          <div className="profile-line"><span className="k">Founded</span><span className="v">{firm.founded}</span></div>
          <div className="profile-line"><span className="k">AUM</span><span className="v">${firm.aum}B</span></div>
          <div className="profile-line"><span className="k">Employees</span><span className="v">{firm.employees}</span></div>
          <div className="profile-line"><span className="k">Active fund</span><span className="v">{firm.activeFunds}</span></div>
          <div className="profile-line"><span className="k">Strategy</span><span className="v">{firm.strategy}</span></div>
          <div className="profile-line sectors-line">
            <span className="k">Sectors</span>
            <span className="v">{firm.sectors.map(s => <span key={s} className="sector-chip">{s}</span>)}</span>
          </div>
        </div>
        <div className="profile-col">
          <h4>Investment focus</h4>
          <p className="profile-focus">{firm.focus}</p>
          <h4 style={{marginTop: 20}}>Key people</h4>
          {(firm.keyPeople || []).map(p => <div key={p} className="profile-person">{p}</div>)}
        </div>
        <div className="profile-col">
          <h4>Recent funds</h4>
          {(firm.recentFunds || []).map(f => (
            <div key={f.name} className="profile-fund">
              <div className="pf-name">{f.name}</div>
              <div className="pf-meta">Vintage {f.vintage} · {f.size}</div>
            </div>
          ))}
          <h4 style={{marginTop: 20}}>Notable portfolio</h4>
          <div className="profile-portfolio">
            {(firm.notablePortfolio || []).map(p => <span key={p} className="portfolio-pill">{p}</span>)}
          </div>
        </div>
      </div>

      <FilterBar filter={filter} setFilter={setFilter} counts={counts} viewMode={viewMode} setViewMode={setViewMode} />

      <div className="story-list">
        {filtered.map(s => (
          <StoryRow
            key={s.id}
            story={s}
            firm={firm}
            expanded={expandedStory === s.id}
            onToggle={() => setExpandedStory(expandedStory === s.id ? null : s.id)}
            viewMode={viewMode}
          />
        ))}
      </div>
    </div>
  );
}

function WatchlistModal({ firms, setFirms, onClose }) {
  const [q, setQ] = useState("");
  const filtered = firms.filter(f =>
    f.name.toLowerCase().includes(q.toLowerCase()) ||
    f.short.toLowerCase().includes(q.toLowerCase()) ||
    f.strategy.toLowerCase().includes(q.toLowerCase())
  );
  const sorted = [...filtered].sort((a, b) => {
    if (a.watched !== b.watched) return a.watched ? -1 : 1;
    return a.name.localeCompare(b.name);
  });
  const toggle = (id) => setFirms(firms.map(f => f.id === id ? { ...f, watched: !f.watched } : f));
  const watchedCount = firms.filter(f => f.watched).length;
  return (
    <div className="modal-scrim" onClick={onClose}>
      <div className="modal" onClick={e => e.stopPropagation()}>
        <div className="modal-header">
          <div>
            <h2 className="modal-title">Manage watchlist</h2>
            <div className="modal-subtitle">Firms tracked for the morning briefing</div>
          </div>
          <button className="modal-close" onClick={onClose}><IconX /></button>
        </div>
        <div className="modal-body">
          <div className="modal-search">
            <IconSearch />
            <input autoFocus value={q} onChange={e => setQ(e.target.value)} placeholder="Search by firm, ticker, or strategy…" />
          </div>
          {sorted.map(f => (
            <div key={f.id} className={`firm-picker-row ${f.watched ? "watched" : ""}`} onClick={() => toggle(f.id)}>
              <div className="check">{f.watched && <IconCheck />}</div>
              <div className="firm-picker-name">
                <div className="name">{f.name}</div>
                <div className="short">{f.short} · {f.strategy}</div>
              </div>
              <div className="firm-picker-meta">{f.hq.split(",")[0]}</div>
              <div>
                <div className="aum">${f.aum}</div>
                <div className="aum-label">AUM</div>
              </div>
              <button className="remove-btn" onClick={(e) => { e.stopPropagation(); toggle(f.id); }} title={f.watched ? "Remove" : "Add"}>
                {f.watched ? <IconX /> : <IconPlus />}
              </button>
            </div>
          ))}
        </div>
        <div className="modal-footer">
          <div className="modal-footer-count"><b>{watchedCount}</b> OF {firms.length} TRACKED</div>
          <div style={{ display: 'flex', gap: 8 }}>
            <button className="btn-ghost" onClick={onClose}>Cancel</button>
            <button className="btn-primary" onClick={onClose}>Save</button>
          </div>
        </div>
      </div>
    </div>
  );
}

function TweaksPanel({ layout, setLayout, density, setDensity, onClose }) {
  return (
    <div className="tweaks-panel">
      <div className="tweaks-header">
        <div className="tweaks-title">TWEAKS</div>
        <button className="modal-close" onClick={onClose} style={{ width: 20, height: 20 }}><IconX /></button>
      </div>
      <div className="tweaks-body">
        <div className="tweak-group">
          <div className="tweak-group-label">Layout</div>
          <div className="tweak-options">
            <button className={layout === "dashboard" ? "active" : ""} onClick={() => setLayout("dashboard")}>DASH</button>
            <button className={layout === "digest" ? "active" : ""} onClick={() => setLayout("digest")}>DIGEST</button>
          </div>
        </div>
        <div className="tweak-group">
          <div className="tweak-group-label">Density</div>
          <div className="tweak-options">
            <button className={density === "comfortable" ? "active" : ""} onClick={() => setDensity("comfortable")}>COMFORT</button>
            <button className={density === "compact" ? "active" : ""} onClick={() => setDensity("compact")}>COMPACT</button>
          </div>
        </div>
      </div>
    </div>
  );
}

function App() {
  const [firms, setFirms] = useState(() => window.PE_FIRMS.map(f => ({
    relationship: "Cold", coverage: [], activeEngagements: [], pitches: [],
    fitScore: 0, lastContact: "—", lastContactWho: "—", ...f,
  })));
  const [view, setView] = useState("briefing");
  const [activeFirm, setActiveFirm] = useState(null);
  const [showWatchlist, setShowWatchlist] = useState(false);
  const [expandedStory, setExpandedStory] = useState(null);

  const TWEAKS = /*EDITMODE-BEGIN*/{
    "layout": "dashboard",
    "density": "comfortable"
  }/*EDITMODE-END*/;
  const [layout, setLayoutRaw] = useState(TWEAKS.layout);
  const [density, setDensityRaw] = useState(TWEAKS.density);
  const [viewMode, setViewMode] = useState(TWEAKS.density);
  const [tweaksOpen, setTweaksOpen] = useState(false);

  const persist = (k, v) => window.parent.postMessage({ type: '__edit_mode_set_keys', edits: { [k]: v } }, '*');
  const setLayout = (v) => { setLayoutRaw(v); persist('layout', v); };
  const setDensity = (v) => { setDensityRaw(v); setViewMode(v); persist('density', v); };

  useEffect(() => {
    const onMsg = (e) => {
      if (e.data?.type === '__activate_edit_mode') setTweaksOpen(true);
      if (e.data?.type === '__deactivate_edit_mode') setTweaksOpen(false);
    };
    window.addEventListener('message', onMsg);
    window.parent.postMessage({ type: '__edit_mode_available' }, '*');
    return () => window.removeEventListener('message', onMsg);
  }, []);

  return (
    <div className="app">
      <div className="brand">
        <div className="brand-mark"></div>
        <div className="brand-name">PE<span>·</span>MONITOR</div>
      </div>
      <Topbar />
      <Sidebar view={view} setView={setView} activeFirm={activeFirm} setActiveFirm={setActiveFirm} firms={firms} onOpenWatchlist={() => setShowWatchlist(true)} />
      <main className={`main layout-${layout}`} data-screen-label={
        activeFirm ? `Firm · ${firms.find(f=>f.id===activeFirm)?.short}` :
        view === "repo" ? "Firm Profiles" :
        view === "saved" ? "Saved" : "Daily Briefing"
      }>
        {view === "firm" && activeFirm ? (
          <FirmDetail firmId={activeFirm} firms={firms} setFirms={setFirms} setActiveFirm={setActiveFirm} setView={setView} expandedStory={expandedStory} setExpandedStory={setExpandedStory} viewMode={viewMode} setViewMode={setDensity} />
        ) : view === "repo" ? (
          <FirmRepo firms={firms} setActiveFirm={setActiveFirm} setView={setView} />
        ) : view === "saved" ? (
          <div className="briefing-header"><div className="kicker">Saved items</div><h1 className="briefing-title">Your <span className="accent">saved stories.</span></h1><div className="briefing-meta"><span>Coming soon — stories you star will appear here.</span></div></div>
        ) : (
          <BriefingView firms={firms} viewMode={viewMode} setViewMode={setDensity} expandedStory={expandedStory} setExpandedStory={setExpandedStory} />
        )}
      </main>

      {showWatchlist && <WatchlistModal firms={firms} setFirms={setFirms} onClose={() => setShowWatchlist(false)} />}
      {tweaksOpen && (
        <TweaksPanel layout={layout} setLayout={setLayout} density={density} setDensity={setDensity} onClose={() => setTweaksOpen(false)} />
      )}
    </div>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
